<div class="row" id="top">
			
	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center">

		<img class="img-circle" src="views/images/icono01.png" width="30%">
		<h3>Lorem Ipsum</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>

	</div>

	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center">

		<img class="img-circle" src="views/images/icono02.png" width="30%">
		<h3>Lorem Ipsum</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>

	</div>

	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center">

		<img class="img-circle" src="views/images/icono03.png" width="30%">
		<h3>Lorem Ipsum</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>

	</div>

	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center">

		<img class="img-circle" src="views/images/icono04.png" width="30%">
		<h3>Lorem Ipsum</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>

	</div>

</div>
